# Programmer:       Tyler DeChellis
# Updated:          October 18, 2023
# Program Purpose:  The purpose of this program is to create order form app for 
#                   the Halloween Outfitters business


#Algorithm
#
# A. Input
#    A. Use tkinter to create a windows application  
#    B. Code to create a background color 
#    C. Code to insert an image
#
# B. Process
#    A. Code to use labels, textboxes and a button to compute the total of the costume 
#
# C. Output
#    A. Code to calculate the total cost with tax with a def function
#
# D. End

# Code to use tkinter to create a windows application

from tkinter import *
window=Tk()

# Code to create the main window

app = Tk()
app.title("Halloween Outfitters")

# Code to create background color to support the theme

app.configure(bg="orange")

# Code to insert an image

HalloweenAppTylerDeChellis =PhotoImage(file="skeleton.png")
label =Label(window, image=HalloweenAppTylerDeChellis)
label.place(relx= 0.3,
            rely=0.8,
            anchor='center')

# Code to use labels, textboxes and a button to compute the total

costume_label = tk.Label(app, text="Type in costume name", bg="orange")
qty_label = tk.Label(app, text="Enter in the quantity", bg="orange")
price_label = tk.Label(app, text="Enter the unit price", bg="orange")
result_label = tk.Label(app, text="", bg="orange")

costume_entry = tk.Entry(app)
qty_entry = tk.Entry(app)
price_entry = tk.Entry(app)

calculate_button = tk.Button(app, text="Calculate Total", command=calculate_total)

costume_label.pack()
costume_entry.pack()
qty_label.pack()
qty_entry.pack()
price_label.pack()
price_entry.pack()

calculate_button.pack()
result_label.pack()

# Code to calculate the total cost with tax with a def function

def calculate_total():
    try:
        qty = int(qty_entry.get())
        unit_price = float(price_entry.get())
        total_cost = qty * unit_price
        total_with_tax = total_cost * 1.07
        result_label.config(text=f'Total Cost with Tax: ${total_with_tax:.2f}')
    except ValueError:
        result_label.config(text="Please enter valid quantity and price.")

# Code to pause the program

x=input("press any key")


